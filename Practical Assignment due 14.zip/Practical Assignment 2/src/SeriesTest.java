import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class SeriesTest {

    private Series series;

    @BeforeEach
    public void setUp() {
        series = new Series();
        Series.seriesList.clear();
        series.captureSeriesDirect("S001", "Extreme Adventures", "13", "12");
    }

    @Test
    public void TestSearchSeries() {
        SeriesModel result = series.searchSeriesById("S001");
        assertNotNull(result, "Series should be found.");
        assertEquals("Extreme Adventures", result.SeriesName);
    }

    @Test
    public void TestSearchSeries_SeriesNotFound() {
        SeriesModel result = series.searchSeriesById("S999");
        assertNull(result, "No series should be found for an invalid ID.");
    }

    @Test
    public void TestUpdateSeries() {
        boolean updated = series.updateSeriesById("S001", "Mountain Quest", "15", "20");
        assertTrue(updated, "Series should be updated.");
        SeriesModel result = series.searchSeriesById("S001");
        assertEquals("Mountain Quest", result.SeriesName);
        assertEquals("15", result.SeriesAge);
        assertEquals("20", result.SeriesNumberOfEpisodes);
    }

    @Test
    public void TestDeleteSeries() {
        boolean deleted = series.deleteSeriesById("S001");
        assertTrue(deleted, "Series should be deleted.");
        assertNull(series.searchSeriesById("S001"));
    }

    @Test
    public void TestDeleteSeries_SeriesNotFound() {
        boolean deleted = series.deleteSeriesById("S999");
        assertFalse(deleted, "Series should not be deleted because it does not exist.");
    }

    @Test
    public void TestSeriesAgeRestriction_AgeValid() {
        assertTrue(series.validateAgeRestriction("10"), "Age 10 should be valid.");
        assertTrue(series.validateAgeRestriction("18"), "Age 18 should be valid.");
        assertFalse(series.validateAgeRestriction("1"), "Age 1 should be invalid.");
        assertFalse(series.validateAgeRestriction("19"), "Age 19 should be invalid.");
        assertFalse(series.validateAgeRestriction("abc"), "Non-numeric age should be invalid.");
    }
}
