import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Series series = new Series();

        while (true) {
            System.out.println("Latest series - 2025");
            System.out.println("************************************");
            System.out.print("Enter (1) to launch menu or any other key to exit: ");
            String choice = scanner.nextLine().trim();

            if (!"1".equals(choice)) break;

            boolean running = true;
            while (running) {
                System.out.println("Please select one of the following menu items:");
                System.out.println("(1) Capture a new series");
                System.out.println("(2) Search for a series");
                System.out.println("(3) Update series age restriction");
                System.out.println("(4) Delete a series");
                System.out.println("(5) Print series report - 2025");
                System.out.println("(6) Exit application");
                System.out.print("Choice: ");

                String menuChoice = scanner.nextLine().trim();

                switch (menuChoice) {
                    case "1":
                        series.CaptureSeries();
                        running = false;
                        break;
                    case "2":
                        series.SearchSeries();
                        running = false;
                        break;
                    case "3":
                        series.UpdateSeries();
                        running = false;
                        break;
                    case "4":
                        series.DeleteSeries();
                        running = false;
                        break;
                    case "5":
                        series.SeriesReport();
                        running = false;
                        break;
                    case "6":
                        series.ExitSeriesApplication();
                        return;
                    default:
                        System.out.println("Invalid option.");
                }
            }
        }
        scanner.close();
    }
}
