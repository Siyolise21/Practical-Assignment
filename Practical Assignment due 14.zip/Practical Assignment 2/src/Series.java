import java.util.ArrayList;
import java.util.Scanner;

public class Series {

    public static ArrayList<SeriesModel> seriesList = new ArrayList<>();
    private final Scanner scanner = new Scanner(System.in);


    public SeriesModel searchSeriesById(String id) {
        for (SeriesModel s : seriesList) {
            if (s.SeriesID.equalsIgnoreCase(id)) {
                return s;
            }
        }
        return null;
    }

    public boolean updateSeriesById(String id, String newName, String newAge, String newEpisodes) {
        SeriesModel s = searchSeriesById(id);
        if (s != null) {
            if (newName != null) s.SeriesName = newName;
            if (newAge != null && validateAgeRestriction(newAge)) s.SeriesAge = newAge;
            if (newEpisodes != null) s.SeriesNumberOfEpisodes = newEpisodes;
        }
        return false;
    }

    public boolean deleteSeriesById(String id) {
        seriesList.removeIf(s -> s.SeriesID.equalsIgnoreCase(id));
        return false;
    }

    public boolean validateAgeRestriction(String age) {
        return age.matches("\\d+") && Integer.parseInt(age) >= 2 && Integer.parseInt(age) <= 18;
    }

    public void captureSeriesDirect(String id, String name, String age, String episodes) {
        if (validateAgeRestriction(age)) {
            seriesList.add(new SeriesModel(id, name, age, episodes));
        }
    }


    public void CaptureSeries() {
        System.out.println("Capture a new series");
        System.out.print("Enter the series id: ");
        String id = scanner.nextLine();

        System.out.print("Enter the series name: ");
        String name = scanner.nextLine();

        String age;
        while (true) {
            System.out.print("Enter the series age restriction (2-18): ");
            age = scanner.nextLine();
            if (validateAgeRestriction(age)) break;
            System.out.println("You have entered the incorrect series age. Please re-enter a valid age.");
        }

        System.out.print("Enter the number of episodes for extreme sports: ");
        String episodes = scanner.nextLine();

        seriesList.add(new SeriesModel(id, name, age, episodes));
        System.out.println("Series processed successfully!!!");
    }

    public void SearchSeries() {
        System.out.print("Enter series id: ");
        String id = scanner.nextLine();
        SeriesModel s = searchSeriesById(id);
        if (s != null) {
            System.out.println("Series ID: " + s.SeriesID);
            System.out.println("Series Name: " + s.SeriesName);
            System.out.println("Series Age Restriction: " + s.SeriesAge);
            System.out.println("Number of Episodes: " + s.SeriesNumberOfEpisodes);
        } else {
            System.out.println("No series data could be found.");
        }
    }

    public void UpdateSeries() {
        System.out.print("Enter series id to update: ");
        String id = scanner.nextLine();
        SeriesModel s = searchSeriesById(id);
        if (s != null) {
            System.out.print("Enter new name (leave blank to keep current): ");
            String name = scanner.nextLine();
            if (name.isEmpty()) name = null;

            String age;
            while (true) {
                System.out.print("Enter new age restriction (leave blank to keep current): ");
                age = scanner.nextLine();
                if (age.isEmpty() || validateAgeRestriction(age)) break;
                System.out.println("Invalid age. Please try again.");
            }
            if (age.isEmpty()) age = null;

            System.out.print("Enter new number of episodes (leave blank to keep current): ");
            String episodes = scanner.nextLine();
            if (episodes.isEmpty()) episodes = null;

            updateSeriesById(id, name, age, episodes);
            System.out.println("Series updated successfully.");
        } else {
            System.out.println("Series not found.");
        }
    }

    public void DeleteSeries() {
        System.out.print("Enter series id to delete: ");
        String id = scanner.nextLine();
        SeriesModel s = searchSeriesById(id);
        if (s != null) {
            System.out.print("Are you sure you want to delete this series? (y/n): ");
            if (scanner.nextLine().equalsIgnoreCase("y")) {
                deleteSeriesById(id);
                System.out.println("Series deleted successfully.");
            }
        } else {
            System.out.println("Series not found.");
        }
    }

    public void SeriesReport() {
        if (seriesList.isEmpty()) {
            System.out.println("No series available.");
        } else {
            for (int i = 0; i < seriesList.size(); i++) {
                SeriesModel s = seriesList.get(i);
                System.out.println("Series " + (i + 1));
                System.out.println("Series ID: " + s.SeriesID);
                System.out.println("Series Name: " + s.SeriesName);
                System.out.println("Series Age Restriction: " + s.SeriesAge);
                System.out.println("Number of Episodes: " + s.SeriesNumberOfEpisodes);
                System.out.println();
            }
        }
    }

    public void ExitSeriesApplication() {
        System.out.println("Exiting application...");
        System.exit(0);
    }
}
