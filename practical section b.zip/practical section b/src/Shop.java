import java.util.Scanner;

public class Shop {
    private final String[] products = {"Product A", "Product B", "Product C"};
    private final double[] prices = {10.99, 5.99, 7.99};
    private final int[] quantities = {10, 20, 15};

    public void displayProducts() {
        System.out.println("Available Products:");
        for (int i = 0; i < products.length; i++) {
            System.out.println((i + 1) + ". " + products[i] + " - R" + prices[i] + " (" + quantities[i] + " in stock)");
        }
    }

    public void purchaseProduct(int productIndex, int quantity) {
        if (productIndex >= 1 && productIndex <= products.length) {
            if (quantities[productIndex - 1] >= quantity) {
                quantities[productIndex - 1] -= quantity;
                System.out.println("You purchased " + quantity + " " + products[productIndex - 1] + "(s) for R" + prices[productIndex - 1] * quantity);
            } else {
                System.out.println("Insufficient stock for " + products[productIndex - 1]);
            }
        } else {
            System.out.println("Invalid product selection");
        }
    }

    public static void main(String[] args) {
        Shop shop = new Shop();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            shop.displayProducts();
            System.out.print("Enter the product number to purchase (0 to exit): ");
            int productIndex = scanner.nextInt();
            if (productIndex == 0) {
                break;
            }
            System.out.print("Enter quantity: ");
            int quantity = scanner.nextInt();
            shop.purchaseProduct(productIndex, quantity);
        }
    }
}